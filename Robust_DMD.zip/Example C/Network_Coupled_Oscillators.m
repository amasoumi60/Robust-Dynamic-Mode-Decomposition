close all;clear all;clc;
%-----A Ring Graph of N nodes-------------
N_os=15;
s=[1:N_os];
ts=[2:N_os 1];  
G=graph(s,ts);
LPCN=laplacian(G);
%--------------------------------------------
%----A Network of Ring Coupled Oscillators-------------
teta(:,1)=1.5*ones(N_os,1);
omega(:,1)=0.3*ones(N_os,1);
x(:,1)=[teta(:,1);omega(:,1)];
t(1)=0;dt=0.01;
d=0.05;
rsvd=2*N_os;
tf=10;
M=tf/dt;
%------------------------------------------------------
for i=1:M
    teta(:,i+1)=teta(:,i)+omega(:,i)*dt;
    omega(:,i+1)=omega(:,i)+(-LPCN*teta(:,i)-diag(d*ones(N_os,1))*omega(:,i))*dt;
    x(:,i+1)=[teta(:,i+1);omega(:,i+1)];
    A=[zeros(N_os,N_os) eye(N_os,N_os);-LPCN -diag(d*ones(N_os,1))];
    Ad=[eye(N_os) eye(N_os)*dt;-LPCN*dt eye(N_os)-diag(d*ones(N_os,1))*dt];
    %Lamda_sys=eig(A);
end

x(:,100:105)=x(:,100:105)+0.1;
X1=x(:,1:M);X2=x(:,2:M+1);

start1=tic;    
[Phi_DMD,Lamda_DMD,K_DMD,b_DMD,z_DMD]=DMD(X1,X2,rsvd,dt);
elapsed_DMD=toc(start1);

start2=tic;          
[Phi_RDMD,Lamda_RDMD,K_RDMD,z_RDMD]=RDMD(X1,X2,rsvd,dt);
elapsed_RDMD=toc(start2);

start3=tic;          
[W_R,Lamda_R,K_R,z_R]=ODMD(X1,X2,N_os,dt);
elapsed_R=toc(start3);

start4=tic;
[Lamda_TDMD,Phi_TDMD,z_TDMD] = tdmd(X1,X2,rsvd);
elapsed_TDMD=toc(start4);
%-------------------------------------------------------------------------
t=0:dt:tf;
 figure;
 plot(t,x(2,:),'linewidth',3);
 hold on;
 plot(t,z_DMD(2,:),'k-.','linewidth',2);
 hold on;
 plot(t,z_R(2,:),'g--','linewidth',3);hold on;
 plot(t,z_RDMD(2,:),'r--','linewidth',2);hold on;
 plot(t,z_TDMD(2,:),'Color',[1 .6 0],'LineStyle',':','linewidth',2.5);
 hold off; xlabel('Time(s)');ylabel('x2');
 legend({'Original System','DMD','ODMD','RDMD','TDMD'},'FontName','Times New Roman','FontSize',12);
 
figure;
pole_real=eigs((Ad-eye(2*N_os))/dt,2*N_os);
pole_DMD=eig((K_DMD-eye(2*N_os))/dt);
pole_RDMD=eig((K_RDMD-eye(2*N_os))/dt);
pole_R=eig((K_R-eye(2*N_os))/dt);
pole_TDMD=eig((diag(Lamda_TDMD)-eye(2*N_os))/dt);
plot(real(pole_real),imag(pole_real),'*','linewidth',1.5);hold on;
plot(real(pole_DMD),imag(pole_DMD),'kd','linewidth',1.5,'MarkerSize',10);hold on;
plot(real(pole_R),imag(pole_R),'gs','linewidth',1.5,'MarkerSize',12);
plot(real(pole_RDMD),imag(pole_RDMD),'rx','linewidth',1.5,'MarkerSize',14);hold on;
pp=plot(real(pole_TDMD),imag(pole_TDMD),'p','linewidth',1.5,'MarkerSize',12);hold on;
pp.Color=[1 .6 0];grid;
hold off;
legend({'Original System','DMD','ODMD','RDMD','TDMD'},'FontName','Times New Roman','FontSize',12);
magnifyOnFigure;
