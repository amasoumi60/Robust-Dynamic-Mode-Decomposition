close all;clear all;clc;
N=500;
x(:,1)=0.3*ones(N,1);

t(1)=0;dt=0.01;
tf=2;
rsvd=20;
M=tf/dt;

Miu=-abs(randn(N/2,1));
%--------Slow Manifold System----------------------
for i=1:M

x(1:N/2,i+1)=x(1:N/2,i)+diag(Miu)*x(1:N/2,i)*dt;
x(N/2+1:N,i+1)=x(N/2+1:N,i)-((x(N/2+1:N,i)-(sum(x(1:N/2,i).^2))))*dt;

end


%----Outliers on data------------
%x(:,200)=x(:,200)+5*ones(size(x,1),1);
%x(:,100:105)=x(:,100:105)+0.5*randn(size(x,1),1);
x(:,100:105)=x(:,100:105)+0.1;

%---------------------------------
X1=x(:,1:M);X2=x(:,2:M+1);


%---- For Lorenz System------------
start1=tic;    
[Phi_DMD,Lamda_DMD,K_DMD,b_DMD,z_DMD]=DMD(X1,X2,rsvd,dt);
elapsed_DMD=toc(start1);

start2=tic;          
[Phi_RDMD,Lamda_RDMD,K_RDMD,z_RDMD]=RDMD1(X1,X2,rsvd,dt);
elapsed_RDMD=toc(start2);

start4=tic;
[Lamda_TDMD,Phi_TDMD,z_TDMD] = tdmd(X1,X2,rsvd);
elapsed_TDMD=toc(start4);

%---------------------------------------------------------
t=0*dt:dt:tf;
figure;
no=2;
plot(t,x(no,:),'linewidth',3);
hold on;
plot(t,z_DMD(2,:),'k-.','linewidth',2);
hold on;
plot(t,z_RDMD(2,:),'r--','linewidth',2);hold on;
plot(t,z_TDMD(2,:),'Color',[1 .6 0],'LineStyle',':','linewidth',2.5);
hold off;
xlabel('Time(s)');ylabel('x2');
legend({'Original System','DMD','RDMD','TDMD'},'FontName','Times New Roman','FontSize',12);

pole_real=Miu;
pole_DMD=eig((K_DMD-eye(size(K_DMD,1)))/dt);
pole_RDMD=eig((K_RDMD-eye(size(K_DMD,1)))/dt);
pole_TDMD=eig((diag(Lamda_TDMD)-eye(size(K_DMD,1)))/dt);

figure;
plot(real(pole_real),imag(pole_real),'*','linewidth',1.5);hold on;
plot(real(pole_DMD),imag(pole_DMD),'kd','linewidth',1.5,'MarkerSize',10);hold on;
plot(real(pole_RDMD),imag(pole_RDMD),'rx','linewidth',1.5,'MarkerSize',14);hold on;
pp=plot(real(pole_TDMD),imag(pole_TDMD),'p','linewidth',1.5,'MarkerSize',14);hold on;
pp.Color=[1 .6 0];
%axis([-1 1 -2 2]);
grid;
hold off;
legend({'Original System','DMD','RDMD','TDMD'},'FontName','Times New Roman','FontSize',12);
%magnifyOnFigure;
    
    
    
    