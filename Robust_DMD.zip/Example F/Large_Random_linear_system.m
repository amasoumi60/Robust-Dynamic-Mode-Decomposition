close all;clear all;clc;
N=420;
x(:,1)=0.3*ones(N,1);
t(1)=0;dt=0.01;
tf=2;
rsvd=25;
sig=10;beta=8/3;rho=28;
M=tf/dt;
% AA=3*randn(N,N);A=AA-diag(diag(AA));
%A=(randn(N,N)-21*eye(N));
A=load('saveA.mat');
A=A.A;
for i=1:M
 
 x(:,i+1)=x(:,i)+A*x(:,i)*dt;
 Lamda_sys=eig(A);

end

%----Outliers on data------------
%x(:,200)=x(:,200)+5*ones(size(x,1),1);
%x(:,100:105)=x(:,100:105)+0.5*randn(size(x,1),1);
x(:,100:105)=x(:,100:105)+0.2;

%---------------------------------
X1=x(:,1:M);X2=x(:,2:M+1);


start1=tic;    
[Phi_DMD,Lamda_DMD,K_DMD,b_DMD,z_DMD]=DMD(X1,X2,rsvd,dt);
elapsed_DMD=toc(start1);

start2=tic;          
[Phi_RDMD,Lamda_RDMD,K_RDMD,z_RDMD]=RDMD(X1,X2,rsvd,dt);
elapsed_RDMD=toc(start2);

start4=tic;
[Lamda_TDMD,Phi_TDMD,z_TDMD] = tdmd(X1,X2,rsvd);
elapsed_TDMD=toc(start4);

%---------------------------------------------------------
t=0*dt:dt:tf;
figure;
no=2;
plot(t,x(no,:),'linewidth',3);
hold on;
plot(t,z_DMD(2,:),'k-.','linewidth',2);
hold on;
plot(t,z_RDMD(2,:),'r--','linewidth',2);hold on;
hold off;
xlabel('Time(s)');ylabel('x2');
legend({'Real System','DMD','RDMD'},'FontName','Times New Roman','FontSize',12);

figure;
pole_real=eigs(A,N);
pole_DMD=eig((K_DMD-eye(rsvd))/dt);
pole_RDMD=eig((K_RDMD-eye(rsvd))/dt);
pole_TDMD=eig((diag(Lamda_TDMD)-eye(rsvd))/dt);
plot(real(pole_real),imag(pole_real),'*','linewidth',1.5);hold on;
plot(real(pole_DMD),imag(pole_DMD),'kd','linewidth',1.5,'MarkerSize',10);hold on;
plot(real(pole_RDMD),imag(pole_RDMD),'rx','linewidth',1.5,'MarkerSize',14);hold on;
pp=plot(real(pole_TDMD),imag(pole_TDMD),'p','linewidth',1.5,'MarkerSize',14);hold on;
pp.Color=[1 .6 0];
%axis([-1 1 -2 2]);
grid;
hold off;
legend({'Real System','DMD','RDMD','TDMD'},'FontName','Times New Roman','FontSize',12);
%magnifyOnFigure;

    
    
    
    