function [Phi,Lamda,Ktilde,z,delt_IRLS]=RDMD(X1,X2,rsvd,dt)
M=size(X1,2);n=size(X1,1);
d=1.5;bm=1.8;lambda=1.5;tol=1e-4;gesmax=20;
[U,S,V]=svd(X1,'econ');
rsvd=min(rsvd,size(U,2));
U_r=U(:,1:rsvd);S_r=S(1:rsvd,1:rsvd);V_r=V(:,1:rsvd);
%------------------------------------------------------------------------
PS_X1=PS_sparse(X1');
Thresh1=sqrt((chi2inv(0.975,2)));
for m=1:M
%if (PS_X1(m)>Thresh1)
    w(m)=min(1,(d^2)/(PS_X1(m)^2));
   %w(m)=1;
%else
 %   w(m)=1;
%end
end
%K1=0.9*[1 -2;1 -1];
K1=0.5*eye(rsvd);

%----------------IRWLS for calculating K Matrix 
%delta_xEst=0.1*ones(5,1);
delt_IRLS=1;
ges=0;
% QQ=eye(M);
T=U_r;
%T=randn(n,rsvd);
%while (norm(delta_xEst,inf)>0.05) && (norm(delta_xEst,inf)<10) %&& (ges<10)
while (norm(delt_IRLS,'fro')>tol) &&(norm(delt_IRLS,inf)<100) && (ges<gesmax)
% [U,S,V]=svd(sqrt(QQ)*X1,'econ');
% rsvd=min(rsvd,size(U,2));
% U_Q=U(:,1:rsvd);S_Q=S(1:rsvd,1:rsvd);V_Q=V(:,1:rsvd);

for m=1:M
r(:,m)=X2(:,m)-T*K1*T'*X1(:,m);
rr(m)=norm(r(:,m));
end
%s_c=1;
s_c=1.4826*bm*median(abs(rr));
for m=1:M
rs(:,m)=r(:,m)/w(m)/s_c;
rs_rr(m)=norm(rs(:,m));
end

%K1new=S_Q\(U_Q'*sqrt(QQ)*X2*V_Q);
q=Sai_f(rs_rr,lambda)./rs_rr;
%QQ=eye(M);
%gama=0;
QQ=diag(q);
gama=1e-3;
%K1new=(T'*X1'*QQ*X1*T+gama*eye(rsvd))\(T'*X1'*QQ*X2*T);
K1new=(T'*X2*QQ*X1'*T)/(T'*X1*QQ*X1'*T+gama*eye(rsvd));

% K1new=(V_Q'*(S_Q^2)*V_Q)\(S_Q*U_Q'*sqrt(QQ)*X2*V_Q);
%K1new=(X1'*QQ*X1)\(X1'*QQ*X2);
ges=ges+1;
%ZZZ(:,:,ges)=inv(T'*X1*QQ*X1'*T);

delt_IRLS=K1-K1new;
K1=K1new;
end
if (norm(delt_IRLS,'fro')<tol)
    Ktilde=K1;
else
    
%sprintf(string('Ridemallllllllllllllllllllllllllllllll'))
display(delt_IRLS);
end
%---------------------------------------------------------------------
[W_r,D]=eig(Ktilde);
Phi=T*W_r;
Lamda=D;
%Lamda=exp(D*dt);
x_init=X1(:,1);
b=Phi\x_init;
z(:,1)=x_init;
for k=1:m
    z(:,k+1)=Phi*(Lamda.^(k))*b;
end
end