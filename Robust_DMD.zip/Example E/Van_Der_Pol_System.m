close all;clear all;clc;
N=2;
x(:,1)=0.3*ones(N,1);
t(1)=0;dt=0.01;
tf=5;
rsvd=2;
M=tf/dt;
% Van Der Pol------------------

for i=1:M
miuu=0.005;
x(1,i+1)=x(1,i)+x(2,i)*dt;
x(2,i+1)=x(2,i)+(miuu*(1-x(1,i)^2)*x(2,i)-x(1,i))*dt;

end

%----Outliers on data------------
%x(:,200)=x(:,200)+5*ones(size(x,1),1);
% x=x+0.01*randn(size(x,1),size(x,2));
% x=x+0.1*randl(size(x,1),size(x,2));
% x=x+0.1*trnd(2,size(x,1),size(x,2));
x(:,100:115)=x(:,100:115)+0.3;
x(:,300:305)=x(:,300:305)+0.3;
%---------------------------------
X1=x(:,1:M);X2=x(:,2:M+1);


start1=tic;    
[Phi_DMD,Lamda_DMD,K_DMD,b_DMD,z_DMD]=DMD(X1,X2,rsvd,dt);
elapsed_DMD=toc(start1);

start2=tic;          
[Phi_RDMD,Lamda_RDMD,K_RDMD,z_RDMD]=RDMD(X1,X2,rsvd,dt);
elapsed_RDMD=toc(start2);

start3=tic;          
[W_R,Lamda_R,K_R,z_R]=ODMD(X1,X2,1,dt);
elapsed_R=toc(start3);

start4=tic;
[Lamda_TDMD,Phi_TDMD,z_TDMD] = tdmd(X1,X2,rsvd);
elapsed_TDMD=toc(start4);

t=0*dt:dt:tf;
figure;
no=2;
plot(t,x(no,:),'linewidth',3);
hold on;
plot(t,z_DMD(2,:),'k-.','linewidth',2);
hold on;
plot(t,z_R(2,:),'g--','linewidth',3);hold on;
plot(t,z_RDMD(2,:),'r--','linewidth',2);hold on;
plot(t,z_TDMD(2,:),'Color',[1 .6 0],'LineStyle',':','linewidth',2.5);
hold off; xlabel('Time(s)');ylabel('x2');
legend({'Original System','DMD','ODMD','RDMD','TDMD'},'FontName','Times New Roman','FontSize',12);

figure;
pole_DMD=eig((K_DMD-eye(N))/dt);
pole_RDMD=eig((K_RDMD-eye(N))/dt);
pole_R=eig((K_R-eye(N))/dt);
pole_TDMD=eig((diag(Lamda_TDMD)-eye(N))/dt);
plot(real(pole_DMD),imag(pole_DMD),'kd','linewidth',1.5,'MarkerSize',10);hold on;
plot(real(pole_R),imag(pole_R),'gs','linewidth',1.5,'MarkerSize',12);
plot(real(pole_RDMD),imag(pole_RDMD),'rx','linewidth',1.5,'MarkerSize',14);hold on;
pp=plot(real(pole_TDMD),imag(pole_TDMD),'p','linewidth',1.5,'MarkerSize',14);hold on;
pp.Color=[1 .6 0];
axis([-1 1 -2 2]);grid;
hold off;
legend({'Original System','DMD','ODMD','RDMD','TDMD'},'FontName','Times New Roman','FontSize',12);
%magnifyOnFigure;
