function [Phi,Lamda,Atilde,b,z]=DMD(X1,X2,rsvd,dt)
m=size(X1,2);
[U,S,V]=svd(X1,'econ');
rsvd=min(rsvd,size(U,2));
U_r=U(:,1:rsvd);S_r=S(1:rsvd,1:rsvd);V_r=V(:,1:rsvd);
%-------DMD for High Order Data-----------------

Atilde=U_r'*X2*V_r/S_r;
% [W_r,D]=eig(Atilde);
% Phi=X2*V_r/S_r*W_r;
% % Phi=U_r*W_r;
% Lamda=D;
% %Lamda=exp(D*dt);
% x_init=X1(:,1);
% b=Phi\x_init;
% z(:,1)=x_init;
% for k=1:m
%     z(:,k+1)=Phi*(Lamda.^k)*b;
% end
%----------Ordinary DMD------------
%Atilde=X2*pinv(X1);
[Phi,D]=eig(Atilde);
Lamda=D;
x_init=X1(:,1);
Phi=U_r*Phi;
b=Phi\x_init;
z(:,1)=x_init;
for k=1:m
    z(:,k+1)=Phi*(Lamda.^k)*b;
end

end