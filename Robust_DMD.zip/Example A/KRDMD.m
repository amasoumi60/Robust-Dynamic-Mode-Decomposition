function [Phi,Lamda,Ktilde,z]=KRDMD(X1,X2,rsvd,dt)
M=size(X1,1);N=size(X1,2);
Y_prime=transpose(reshape(X2',1,[]));
d=1.5;bm=1.2;lambda=1.5;tol=1e-6;gesmax=100;
%---------------------------Calculating Weights based on PS----------------
PSX=PS_sparse(X1');
Thresh1=sqrt((chi2inv(0.975,2)));
for m=1:N
if (PSX(m)>Thresh1)
    w(m)=min(1,(d^2)/(PSX(m)^2));
else
    w(m)=1;
end
end

for j=1:M
    aa=zeros(M,1);
    delt_IRLS=ones(N,1);
%----------------IRWLS for calculating A Matrix 
ges=0;
while (norm(delt_IRLS)>tol) && (norm(delt_IRLS)<100) && (ges<gesmax)
r=X2(j,:)'-X1'*aa;
s_c=1.4826*bm*median(abs(r));
rs=r./w'/s_c;
q=Sai_f(rs',lambda)./rs';
Q=diag(q);
gama=1e-3;
aa_new=(X1*Q*X1'+gama*eye(M))\(X1*Q*X2(j,:)');
ges=ges+1;
delt_IRLS=aa-aa_new;
aa=aa_new;
end
if (norm(delt_IRLS)<tol)
    Ktilde(j,:)=aa';
else
    display(delt_IRLS);
    end
end
%-------- Calculating the Response------------------------------------
[W_r,D]=eig(Ktilde);
Phi=W_r;
Lamda=D;
%Lamda=exp(D*dt);
x_init=X1(:,1);
b=Phi\x_init;
z(:,1)=x_init;
for k=1:N
    z(:,k+1)=Phi*(Lamda.^(k))*b;
end
end