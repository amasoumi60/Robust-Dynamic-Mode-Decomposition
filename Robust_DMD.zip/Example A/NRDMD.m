function [Phi,Lamda,Ktilde,z,delt_IRLS]=NRDMD(X1,X2,rsvd,dt)
M=size(X1,2);n=size(X1,1);
d=1.5;bm=1.2;lambda=1.5;tol=1e-6;gesmax=100;
[U,S,V]=svd(X1,'econ');
%rsvd=min(rsvd,size(U,2));
U_r=U(:,1:rsvd);S_r=S(1:rsvd,1:rsvd);V_r=V(:,1:rsvd);
%------------------------------------------------------------------------
PS_X1=PS_sparse(X1');
Thresh1=sqrt((chi2inv(0.975,2)));

for m=1:M
    if (PS_X1(m)>Thresh1)
    w(m)=min(1,(d^2)/(PS_X1(m)^2));
    else
    w(m)=1;
    end
 end
K1=0.5*eye(rsvd);

%----------------IRWLS for calculating K Matrix 

delt_IRLS=1;
ges=0;
T=U_r;
while (norm(delt_IRLS,'fro')>tol) &&(norm(delt_IRLS,inf)<100) && (ges<gesmax)

for m=1:M
r(:,m)=X2(:,m)-T*K1*T'*X1(:,m);
rr(m)=norm(r(:,m));
end
%s_c=1;
s_c=1.4826*bm*median(abs(rr));
for m=1:M
rs(:,m)=r(:,m)/w(m)/s_c;
rs_rr(m)=norm(rs(:,m));
end
q=Sai_f(rs_rr,lambda)./rs_rr;
QQ=diag(q);
gama=1e-4;
K1new=(T'*X2*QQ*X1'*T)/(T'*X1*QQ*X1'*T+gama*eye(rsvd));
ges=ges+1;

delt_IRLS=K1-K1new;
K1=K1new;
end
if (norm(delt_IRLS,'fro')<tol)
    Ktilde=K1;
else
    
display(delt_IRLS);
end
%------------------------Response Reconstruction---------------------------
[W_r,D]=eig(Ktilde);
Phi=T*W_r;
Lamda=D;
x_init=X1(:,1);
b=Phi\x_init;
z(:,1)=x_init;
for k=1:m
    z(:,k+1)=Phi*(Lamda.^(k))*b;
end
end