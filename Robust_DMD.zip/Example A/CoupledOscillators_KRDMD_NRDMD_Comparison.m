close all;clear all;clc;
%-----A Ring Graph of N nodes-------------
N_os=15;
s=[1:N_os];
ts=[2:N_os 1];  
G=graph(s,ts);
LPCN=laplacian(G);
%--------------------------------------------
%----A Network of Ring Coupled Oscillators-------------
teta(:,1)=1.5*zeros(N_os,1);
omega(:,1)=0.3*ones(N_os,1);
x(:,1)=[teta(:,1);omega(:,1)];
t(1)=0;dt=0.01;
d=0.05;
rsvd=2*N_os;
tf=5;
N=tf/dt;
%------------------------------------------------------
for i=1:N
    teta(:,i+1)=teta(:,i)+omega(:,i)*dt;
    omega(:,i+1)=omega(:,i)+(-LPCN*teta(:,i)-diag(d*ones(N_os,1))*omega(:,i))*dt;
    x(:,i+1)=[teta(:,i+1);omega(:,i+1)];
%     A=[zeros(N_os,N_os) eye(N_os,N_os);-LPCN -diag(d*ones(N_os,1))];
%     Ad=[eye(N_os) eye(N_os)*dt;-LPCN*dt eye(N_os)-diag(d*ones(N_os,1))*dt];
    %Lamda_sys=eig(A);
end
x_intact=x;
x(:,100:105)=x(:,100:105)+0.2;
%x(:,150:155)=x(:,150:155)+0.2;
X1=x(:,1:N);X2=x(:,2:N+1);

startN=tic;          
[Phi_NRDMD,Lamda_NRDMD,K_NRDMD,z_NRDMD]=NRDMD(X1,X2,rsvd,dt);
elapsed_NRDMD=toc(startN);

startK=tic;
[Phi_KRDMD,Lamda_KRDMD,K_KRDMD,z_KRDMD]=KRDMD(X1,X2,rsvd,dt);
elapsed_KRDMD=toc(startK);
for i=1:N
    erms_NRDMD(i)=norm(z_NRDMD(:,i)-x_intact(:,i));
    erms_Kron(i)=norm(z_KRDMD(:,i)-x_intact(:,i));
end
for i=1:N
    sme_NRDMD(i)=sum(erms_NRDMD(1:i));
    sme_Kron(i)=sum(erms_Kron(1:i));
end
%--------------------Ploting Results---------------------------------------
t=0:dt:tf;
 figure;
 plot(t,x(2,:),'linewidth',3);
 hold on;
 plot(t,z_NRDMD(2,:),'r--','linewidth',2.5);hold on;
 plot(t,z_KRDMD(2,:),'k:','linewidth',2.5);
 hold off; xlabel('Time(s)');ylabel('x2');
 legend({'Original System','Norm-based RDMD','Kronecker-based RDMD'},'FontName','Times New Roman','FontSize',12);
 figure;
 plot(t(1:end-1),sme_NRDMD,'r--','linewidth',2);hold on;plot(t(1:end-1),sme_Kron,'k:','linewidth',2.5);hold off;
 xlabel('Time(s)');ylabel('Cumulative Error');
 legend({'Norm-based RDMD','Kronecker-based RDMD'},'FontName','Times New Roman','FontSize',12);

